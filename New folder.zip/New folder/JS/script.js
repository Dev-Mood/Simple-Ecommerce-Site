function myFunc() {
	var x = document.getElementById('navbar-top');
	if (x.className === "caretJS") {
		x.className += "responsive";
	} else {
		x.className = "navbar-top";
	}
}