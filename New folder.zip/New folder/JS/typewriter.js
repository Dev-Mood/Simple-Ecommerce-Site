var i = 0;
var txt = 'Welcome to my simple E-commerce Store.';
var speed = 50;

function typeWriter() {
	if (i < txt.length) {
		document.getElementById("writer").innerHTML += txt.charAt(i);
		i++;
		setTimeout(typeWriter, speed);
	}
}